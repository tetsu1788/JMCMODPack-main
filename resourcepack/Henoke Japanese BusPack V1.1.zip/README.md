# English

This resource pack adds Japanese-style buses.
Includes scripts for destination displays and more.

The original part this [license](https://gist.githubusercontent.com/Henoke-ekoneH/f69fdaeb6ecbd6ec78c1efd9e91013fc/raw/35310bd970013cdb4ebc6e3c048309d5779ca9ca/HenokeMTRResoursePackLisence.md) applies!
Fonts are licensed under their own font license (found in the font directory)

## Add objects
- Shirataka Bus AURORA: A-Series (fictional)

Feel free to use it for your own bus company, such as retexturing it.
(Please read the license.)

Enter bus route numbers as "letter portion|number portion" (e.g., "AB|01").
Use the custom destination field to enter bus route destinations as "via|destination (CJK)|destination (Non CJK)" (e.g., "丸子営業所経由|新静岡駅|Shin-Shizuoka").

## Prerequisite Mods
- Minecraft Transit Railway (Version 3)
- MTR-NTE or MTR-ANTE

Not intended to work with the MTR4 series.

# 日本語

日本風バスを追加するリソースパックです。
行先表示器等のスクリプトを搭載しています。

オリジナル部分は、この[ライセンス](https://gist.githubusercontent.com/Henoke-ekoneH/f69fdaeb6ecbd6ec78c1efd9e91013fc/raw/35310bd970013cdb4ebc6e3c048309d5779ca9ca/HenokeMTRResoursePackLisence.md)が適用されます！
フォント部分はフォントごとのライセンスが適用されます（フォントディレクトリに存在）

## 追加されるもの
- 白鷹自動車 AURORA: A-Series（架空）

リテクスチャしてオリジナルのバス会社用にするなど、ご自由にお使いください
（ライセンスはご一読ください）

バス路線の系統番号は、「文字部分|数字部分」のように入力してください（例：「AB|01」）
バス路線の行き先はカスタム行き先欄を使用し、「経由地|行き先（日本語）|行き先（英語）」のように入力してください（例：「丸子営業所経由|新静岡|Shin-Shizuoka」）

## 前提MOD
- Minecraft Transit Railway（バージョン3）
- MTR-NTEまたはMTR-ANTE

MTR4系での動作は想定していません。