include(Resources.id("jsblock:scripts/pids_util.js"));

function create(ctx, state, pids) {
    state.blinkTimer = 0;
    state.noticeIdx = 0;
    state.langIdx = 0;
    state.pageIdx = 0;
    state.noticePhase = "typing";
    state.noticeStart = Date.now();
}
function dispose(ctx, state, pids) {}
function render(ctx, state, pids) {
    state.blinkTimer++;
    let arrivals = pids.arrivals();
    let now = Date.now();

    try { drawShell(ctx, pids); } catch (e) {}

    Texture.create()
        .texture("mtr:textures/block/white.png")
        .color(0x333333)
        .pos(-32, -8)
        .size(pids.width + 64, pids.height + 16)
        .draw(ctx);

    Texture.create()
        .texture("mtr:textures/block/white.png")
        .color(0x000000)
        .pos(-24, 8)
        .size(pids.width + 48, pids.height - 8)
        .draw(ctx);

    Texture.create()
        .texture("mtr:textures/block/white.png")
        .color(0xFFFFFF)
        .pos(-24, 25)
        .size(pids.width + 48, 1)
        .draw(ctx);

    Texture.create()
        .texture("mtr:textures/block/white.png")
        .color(0xFFFFFF)
        .pos(-24, 44)
        .size(pids.width + 48, 1)
        .draw(ctx);

    let firstTrain = arrivals.get(0);
    let showServiceEnd = false;
    let showArrivalNotice = false;
    let showDoorCloseNotice = false;

    if (!firstTrain) {
        showServiceEnd = true;
    } else {
        let etaArrive = (firstTrain.arrivalTime() - now) / 1000;
        let etaDepart = (firstTrain.departureTime() - now) / 1000;
        showServiceEnd = etaArrive > 5400;
        if (!showServiceEnd) {
            showArrivalNotice = (etaArrive > 0 && etaArrive <= 60);
            showDoorCloseNotice = (etaDepart > 0 && etaDepart <= 10);
        }
    }

    if (showServiceEnd) {
        Text.create()
            .text("☆☆☆ 本日は終了しました ☆☆☆")
            .pos(pids.width / 2, 12)
            .scale(1.05)
            .centerAlign()
            .color(0xb9f47f)
            .draw(ctx);
        return;
    }

    if (firstTrain) {
        Text.create()
            .text(firstTrain.platformName())
            .pos(-17, -2)
            .scale(0.85)
            .color(0xFFFFFF)
            .draw(ctx);

        let routeColors = [firstTrain.routeColor()];
        for (let i = 1; i < 8; i++) {
            let t = arrivals.get(i);
            if (!t) break;
            let c = t.routeColor();
            if (routeColors.indexOf(c) < 0) routeColors.push(c);
            if (routeColors.length >= 2) break;
        }
        let blockColor = routeColors.length >= 2 ? 0x0000FF : firstTrain.routeColor();
        Texture.create()
            .texture("mtr:textures/block/white.png")
            .color(blockColor)
            .pos(-9, -6)
            .size(5, 14)
            .draw(ctx);

        let jpSet = [];
        let enSet = [];
        for (let i = 0; i < 8; i++) {
            let t = arrivals.get(i);
            if (!t) break;
            let d = String(t.destination() || "");
            let lang = d.split("|");
            let jpRaw = (lang[0] || "").trim();
            let enRaw = lang.length > 1 ? (lang[1] || "").trim() : "";
            if (!jpRaw) continue;
            let jpStops = jpRaw.split(/[・、\s]+/).map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; });
            let enStops = enRaw ? enRaw.split(/\s*,\s*/).map(function(s) { return s.trim(); }).filter(function(s) { return s.length > 0; }) : [];
            if (jpStops.length === 0) jpStops = [jpRaw];
            for (let j = 0; j < jpStops.length; j++) {
                if (jpSet.indexOf(jpStops[j]) < 0) jpSet.push(jpStops[j]);
            }
            for (let j = 0; j < enStops.length; j++) {
                if (enSet.indexOf(enStops[j]) < 0) enSet.push(enStops[j]);
            }
            if (jpSet.length >= 4) break;
        }
        if (jpSet.length === 0) jpSet = [String(firstTrain.destination() || "").split("|")[0] || ""];
        if (enSet.length === 0) enSet = jpSet.slice();
        let destJp = jpSet.slice(0, 4).join(" ") + "方面";
        let destEn = "To " + enSet.slice(0, 4).join(", ");
        Text.create()
            .text(destJp)
            .pos(1, -6)
            .scale(1.0)
            .color(0xFFFFFF)
            .draw(ctx);
        Text.create()
            .text(destEn)
            .pos(1, 3)
            .scale(0.5)
            .color(0xFFFFFF)
            .draw(ctx);
    }

    if (firstTrain) {
        let baseY = 12;
        let rawRoute = firstTrain.routeNumber();
        let routeNumText = (rawRoute !== null && rawRoute !== undefined) ? String(rawRoute).trim() : "";
        let hasRoute = routeNumText.length > 0;
        let blockColor = getColorByKeyword(routeNumText, firstTrain.routeColor());

        if (hasRoute && !isKaeso(firstTrain, pids)) {
            Texture.create()
                .texture("mtr:textures/block/white.png")
                .color(blockColor)
                .pos(-20, baseY - 2)
                .size(32, 13)
                .draw(ctx);
            Text.create()
                .text(TextUtil.cycleString(routeNumText))
                .pos(-4, baseY + 1)
                .size(30, 9)
                .stretchXY()
                .centerAlign()
                .scale(0.85)
                .color(0xFFFFFF)
                .draw(ctx);
        } else if (!isKaeso(firstTrain, pids)) {
            Text.create()
                .text("先発")
                .pos(-20, baseY)
                .scale(1.0)
                .color(0xFFFFFF)
                .draw(ctx);
        }

        Text.create()
            .text(isKaeso(firstTrain, pids) ? TextUtil.cycleString("回送|Not in service") : TextUtil.cycleString(firstTrain.destination()))
            .pos(50, baseY)
            .size(52, 9)
            .stretchXY()
            .centerAlign()
            .scale(1.05)
            .color(0xFFFFFF)
            .draw(ctx);

        Text.create()
            .text(TextUtil.cycleString(firstTrain.carCount() + "両|" + firstTrain.carCount() + " cars"))
            .pos(pids.width / 2 + 30, baseY)
            .scale(1.05)
            .centerAlign()
            .color(0xFFFFFF)
            .draw(ctx);

        Text.create()
            .text(formatTime(firstTrain.arrivalTime()))
            .pos(pids.width + 20, baseY)
            .rightAlign()
            .scale(1.05)
            .color(0xFFFFFF)
            .draw(ctx);
    }

    let secondTrain = arrivals.get(1);
    let blinkOn = Math.floor(now / 500) % 2 === 0;
    let noticeY = 31;
    if (showArrivalNotice) {
        if (blinkOn) {
            Text.create().text("🚊").pos(12, noticeY).scale(1.1).color(0xFFDD00).draw(ctx);
            Text.create()
                .text(TextUtil.cycleString("電車がまいります|Train arriving"))
                .pos(pids.width / 2, noticeY)
                .scale(1.1)
                .centerAlign()
                .color(0xFFDD00)
                .draw(ctx);
            Text.create().text("🚊").pos(pids.width - 12, noticeY).scale(1.1).rightAlign().color(0xFFDD00).draw(ctx);
        } else {
            Texture.create()
                .texture("mtr:textures/block/white.png")
                .color(0xFFDD00)
                .pos(-24, 25)
                .size(pids.width + 48, 21)
                .draw(ctx);
            Text.create().text("🚊").pos(12, noticeY).scale(1.1).color(0x000000).draw(ctx);
            Text.create()
                .text(TextUtil.cycleString("電車がまいります|Train arriving"))
                .pos(pids.width / 2, noticeY)
                .scale(1.1)
                .centerAlign()
                .color(0x000000)
                .draw(ctx);
            Text.create().text("🚊").pos(pids.width - 12, noticeY).scale(1.1).rightAlign().color(0x000000).draw(ctx);
        }
    } else if (showDoorCloseNotice) {
        Text.create()
            .text(TextUtil.cycleString("ドアが閉まります|Door closing"))
            .pos(pids.width / 2, noticeY)
            .scale(1.1)
            .centerAlign()
            .color(0xFFDD00)
            .draw(ctx);
    } else {
        if (secondTrain) {
            let baseY = 31;
            let rawRoute = secondTrain.routeNumber();
            let routeNumText = (rawRoute !== null && rawRoute !== undefined) ? String(rawRoute).trim() : "";
            let hasRoute = routeNumText.length > 0;
            let blockColor = getColorByKeyword(routeNumText, secondTrain.routeColor());

            if (hasRoute && !isKaeso(secondTrain, pids)) {
                Texture.create()
                    .texture("mtr:textures/block/white.png")
                    .color(blockColor)
                    .pos(-20, baseY - 2)
                    .size(32, 13)
                    .draw(ctx);
                Text.create()
                    .text(TextUtil.cycleString(routeNumText))
                    .pos(-4, baseY + 1)
                    .size(30, 9)
                    .stretchXY()
                    .centerAlign()
                    .scale(0.85)
                    .color(0xFFFFFF)
                    .draw(ctx);
            } else if (!isKaeso(secondTrain, pids)) {
                Text.create()
                    .text("次発")
                    .pos(-20, baseY)
                    .scale(1.0)
                    .color(0xFFFFFF)
                    .draw(ctx);
            }

            Text.create()
                .text(isKaeso(secondTrain, pids) ? TextUtil.cycleString("回送|Not in service") : TextUtil.cycleString(secondTrain.destination()))
                .pos(50, baseY)
                .size(52, 9)
                .stretchXY()
                .centerAlign()
                .scale(1.05)
                .color(0xFFFFFF)
                .draw(ctx);

            Text.create()
                .text(TextUtil.cycleString(secondTrain.carCount() + "両|" + secondTrain.carCount() + " cars"))
                .pos(pids.width / 2 + 30, baseY)
                .scale(1.05)
                .centerAlign()
                .color(0xFFFFFF)
                .draw(ctx);
            Text.create()
                .text(formatTime(secondTrain.arrivalTime()))
                .pos(pids.width + 20, baseY)
                .rightAlign()
                .scale(1.05)
                .color(0xFFFFFF)
                .draw(ctx);
        }
    }

    let nMaxW = pids.width - 40;
    let nSegs = (state.langIdx === 0) ? noticeData[state.noticeIdx].jp : noticeData[state.noticeIdx].en;
    let nPages = splitNoticePages(nSegs, nMaxW);
    if (state.pageIdx >= nPages.length) state.pageIdx = 0;
    let nPage = nPages[state.pageIdx];
    let nTotal = totalNoticeChars(nPage);
    let nElapsed = now - state.noticeStart;

    if (state.noticePhase === "pause") {
        if (nElapsed >= NOTICE_PAUSE_MS) {
            state.pageIdx++;
            if (state.pageIdx >= nPages.length) {
                state.pageIdx = 0;
                state.langIdx++;
                if (state.langIdx >= 2) {
                    state.langIdx = 0;
                    state.noticeIdx = (state.noticeIdx + 1) % noticeData.length;
                }
            }
            state.noticePhase = "typing";
            state.noticeStart = now;
            nSegs = (state.langIdx === 0) ? noticeData[state.noticeIdx].jp : noticeData[state.noticeIdx].en;
            nPages = splitNoticePages(nSegs, nMaxW);
            nPage = nPages[state.pageIdx];
            nTotal = totalNoticeChars(nPage);
            drawNoticePage(ctx, nPage, 0, 50);
        } else {
            drawNoticePage(ctx, nPage, nTotal, 50);
        }
    } else {
        let nShown = Math.min(nTotal, Math.floor(nElapsed / NOTICE_CHAR_MS));
        if (nShown >= nTotal) {
            state.noticePhase = "pause";
            state.noticeStart = now;
        }
        drawNoticePage(ctx, nPage, nShown, 50);
    }

    Text.create()
        .text(formatTime(now))
        .pos(pids.width + 20, 50)
        .rightAlign()
        .scale(1.05)
        .color(0xFFFFFF)
        .draw(ctx);
}

let noticeData = [
    {
        jp: [
            {t: "ホームで列車をお待ちの際は、", c: 0xFFFFFF},
            {t: "危険", c: 0xFF4040},
            {t: "ですので", c: 0xFFFFFF},
            {t: "黄色い線", c: 0xFFDD00},
            {t: "の内側までお下がりください", c: 0xFFFFFF}
        ],
        en: [
            {t: "Please stand behind the ", c: 0xFFFFFF},
            {t: "yellow line", c: 0xFFDD00},
            {t: " when waiting for trains", c: 0xFFFFFF}
        ]
    },
    {
        jp: [
            {t: "電車とホームの", c: 0xFFFFFF},
            {t: "隙間", c: 0xFFDD00},
            {t: "にご注意ください", c: 0xFFFFFF}
        ],
        en: [
            {t: "Mind the ", c: 0xFFFFFF},
            {t: "gap", c: 0xFFDD00},
            {t: " between the train and platform", c: 0xFFFFFF}
        ]
    },
    {
        jp: [
            {t: "駆け込み乗車", c: 0xFF4040},
            {t: "はご遠慮ください", c: 0xFFFFFF}
        ],
        en: [
            {t: "Please do not ", c: 0xFFFFFF},
            {t: "rush", c: 0xFF4040},
            {t: " into the train", c: 0xFFFFFF}
        ]
    },
    {
        jp: [
            {t: "足元", c: 0xFFDD00},
            {t: "にご注意ください", c: 0xFFFFFF}
        ],
        en: [
            {t: "Please mind your ", c: 0xFFFFFF},
            {t: "step", c: 0xFFDD00}
        ]
    },
    {
        jp: [
            {t: "お忘れ物", c: 0xFFDD00},
            {t: "は駅係員までお届けください", c: 0xFFFFFF}
        ],
        en: [
            {t: "Please report ", c: 0xFFFFFF},
            {t: "lost items", c: 0xFFDD00},
            {t: " to station staff", c: 0xFFFFFF}
        ]
    }
];

const NOTICE_CHAR_MS = 70;
const NOTICE_PAUSE_MS = 1800;
const NOTICE_SCALE = 0.85;
const NOTICE_FULL_W = 8.35;
const NOTICE_HALF_W = 5.14;

const NOTICE_WIDTH_MAP = {
    32: 4.0, 33: 2.47, 34: 3.94, 35: 5.69, 36: 5.04, 37: 7.71, 38: 6.54, 39: 2.21,
    40: 2.85, 41: 2.85, 42: 4.82, 43: 5.04, 44: 2.46, 45: 2.84, 46: 2.46, 47: 3.5,
    48: 5.04, 49: 5.04, 50: 5.04, 51: 5.04, 52: 5.04, 53: 5.04, 54: 5.04, 55: 5.04,
    56: 5.04, 57: 5.04, 58: 2.46, 59: 2.46, 60: 5.04, 61: 5.04, 62: 5.04, 63: 4.06,
    64: 7.91, 65: 5.91, 66: 5.85, 67: 5.59, 68: 6.48, 69: 4.91, 70: 4.74, 71: 6.39,
    72: 6.66, 73: 3.26, 74: 2.72, 75: 5.7, 76: 4.84, 77: 8.18, 78: 6.98, 79: 6.96,
    80: 5.45, 81: 6.96, 82: 5.69, 83: 4.84, 84: 5.02, 85: 6.58, 86: 5.56, 87: 8.39,
    88: 5.6, 89: 5.3, 90: 5.07, 91: 2.91, 92: 3.5, 93: 2.91, 94: 5.04, 95: 3.72,
    96: 2.91, 97: 5.18, 98: 5.51, 99: 4.41, 100: 5.51, 101: 5.12, 102: 3.27, 103: 5.51,
    104: 5.65, 105: 2.53, 106: 2.53, 107: 5.18, 108: 2.53, 109: 8.49, 110: 5.65,
    111: 5.41, 112: 5.51, 113: 5.51, 114: 3.87, 115: 4.31, 116: 3.58, 117: 5.65,
    118: 4.81, 119: 7.31, 120: 4.93, 121: 4.82, 122: 4.24, 123: 3.43, 124: 4.85,
    125: 3.43, 126: 5.04
};

function estNoticeWidth(str) {
    let w = 0;
    for (let ch of str) {
        let code = ch.codePointAt(0);
        let cw = NOTICE_WIDTH_MAP[code];
        if (cw === undefined) cw = (code > 0x2E7F ? NOTICE_FULL_W : NOTICE_HALF_W);
        w += cw * NOTICE_SCALE;
    }
    return w;
}

function totalNoticeChars(segs) {
    let n = 0;
    for (let s of segs) n += s.t.length;
    return n;
}

function splitNoticePages(segs, maxW) {
    let pages = [];
    let cur = [];
    let curW = 0;
    for (let s of segs) {
        let sw = estNoticeWidth(s.t);
        if (curW + sw > maxW && cur.length > 0) {
            pages.push(cur);
            cur = [];
            curW = 0;
        }
        cur.push(s);
        curW += sw;
    }
    if (cur.length > 0) pages.push(cur);
    return pages;
}

function colorToSectionCode(c) {
    if (c === 0xFFDD00) return "e";
    if (c === 0xFF4040) return "c";
    return "f";
}

function segsToSectionString(segs, limit) {
    let out = "";
    let seen = 0;
    for (let s of segs) {
        if (seen >= limit) break;
        let take = Math.min(limit - seen, s.t.length);
        seen += take;
        out += "\u00a7" + colorToSectionCode(s.c) + s.t.substring(0, take);
    }
    return out;
}

function drawNoticePage(ctx, segs, shownChars, y) {
    let str = segsToSectionString(segs, shownChars);
    if (str.length > 0) {
        Text.create().text(str).pos(0, y).scale(NOTICE_SCALE).leftAlign().color(0xFFFFFF).draw(ctx);
    }
}

function getColorByKeyword(text, defaultColor) {
    if (text.includes("準急") || text.includes("Semi-Express")) return 0x009988;
    if (text.includes("通勤快速") || text.includes("Commuter Rapid")) return 0xdd2222;
    if (text.includes("区間快速") || text.includes("Semi-Rapid")) return 0x009944;
    if (text.includes("特急") || text.includes("Limited Express")) return 0x8822aa;
    if (text.includes("急行") || text.includes("Express")) return 0x0055bb;
    if (text.includes("快速") || text.includes("Rapid")) return 0xff7800;
    if (text.includes("各停") || text.includes("普通") || text.includes("Local")) return 0x000000;
    return defaultColor;
}


function formatTime(timestamp) {
    let date = new Date(timestamp);
    let h = String(date.getHours()).padStart(2, "0");
    let m = String(date.getMinutes()).padStart(2, "0");
    return h + ":" + m;
}

function isKaeso(t, pids) {
    if (!t) return false;
    try {
        let route = t.route();
        if (!route) return false;
        let platforms = route.getPlatforms();
        if (!platforms || platforms.size() === 0) return false;
        let currentStation = pids.station();
        if (!currentStation) return false;
        let curName = "" + currentStation.name;
        for (let i = 0; i < platforms.size(); i++) {
            if ("" + platforms.get(i).getStationName() === curName) {
                return i >= platforms.size() - 1;
            }
        }
        return false;
    } catch (e) {}
    try {
        let d = String(t.destination() || "");
        if (d.indexOf("回送") >= 0 || d.indexOf("回場") >= 0 || d.indexOf("回场") >= 0) return true;
        if (d.indexOf("kaiso") >= 0 || d.indexOf("kaesou") >= 0) return true;
    } catch (e2) {}
    return false;
}

const SHELL_T = 0.18;
const SHELL_COLOR = 0x333333;
const SHELL_BACK_SIGN = 1;

function drawShell(ctx, pids) {
    let rm = ctx.renderManager();
    let V = function(x, y, z) { return new Vector3f(x, y, z); };
    let SHELL_RT = "EXTERIOR";
    let x1 = -32 / 96;
    let x2 = (pids.width + 32) / 96;
    let yT = 8 / 96;
    let yB = -(pids.height + 8) / 96;
    let z0 = 0.0;
    let zB = -SHELL_BACK_SIGN * SHELL_T;
    let Q = function(nx, ny, nz) { return QuadDrawCall.create().renderType(SHELL_RT).texture("mtr:textures/block/white.png").color(SHELL_COLOR).normal(nx, ny, nz); };
    rm.draw(Q(0, 1, 0).quad(V(x1, yT, z0), V(x2, yT, z0), V(x2, yT, zB), V(x1, yT, zB)));
    rm.draw(Q(0, -1, 0).quad(V(x1, yB, z0), V(x1, yB, zB), V(x2, yB, zB), V(x2, yB, z0)));
    rm.draw(Q(-1, 0, 0).quad(V(x1, yB, z0), V(x1, yT, z0), V(x1, yT, zB), V(x1, yB, zB)));
    rm.draw(Q(1, 0, 0).quad(V(x2, yB, z0), V(x2, yB, zB), V(x2, yT, zB), V(x2, yT, z0)));
    rm.draw(Q(0, 0, 1).quad(V(x1, yB, zB), V(x2, yB, zB), V(x2, yT, zB), V(x1, yT, zB)));
}