# English

This is a decorative resource pack adding several Japanese-style railway-related items.
All items are purely decorative and do not function.
They are added as NTE eye candy.

## Items Added
- ATS track sensors
- Curve markers (600m, 300m, 150m)
- Stop position targets (2-car, 4-car, 6-car, 8-car, 10-car)
- Departure reaction signs (Hokkaido style)
- Yellow and black railings
- Boarding point indicators (Hokkaido)
- 4 types of fencing (colour variations available, including rail fencing)
- Platform roofs (added as rails. Can be curved)
- 8 types of platform (curved possible, added as rails)
- Station benches (red, yellow, blue)
- Sapporo Municipal Subway Wind Shelter
- Point Signage (Standard, Spring, Derailment)
- Canopies (for station&bus rotaly, white/yellow)

When using roofs, stack rails in two layers: select pillars for the lower layer and roofs for the upper layer.
Items using rails may display differently depending on length. Find the optimal length. Using eye candy alongside these also works well.

## Prerequisite MODS
- Minecraft Transit Railway (Version 3)
- MTR-NTE or MTR-ANTE

Operation with MTR4 series is not anticipated.

# 日本語

日本風の鉄道周りにある物を何個か追加する、装飾用リソースパックです。
すべて装飾品で、動作はしません
NTEのアイキャンディとして追加されます

## 追加されるもの
- ATS地上子
- 曲線標（600m、300m、150m）
- 停止位置目標（2両、4両、6両、8両、10両）
- 出発反応標識（北海道風）
- 黄色と黒の柵
- 乗車口案内（北海道）
- フェンス4種（カラーバリエーションあり、レールも）
- ホーム屋根（レールとして追加。カーブ可能）
- ホーム8種（カーブ可能、レールとして追加。）
- 駅のベンチ（赤、黄、青）
- 札幌市営地下鉄風シェルター
- 転てつ器標識（標準、スプリング、脱線）
- 駅前・バスロータリーの屋根2種

屋根を使う場合は、レールを二段重ねて、下の段に柱、上の段に屋根を選択してください。
レールを使ったものは長さによって表示が変わる場合があります。ちょうどいい長さを見つけてください。また、アイキャンディも併用するとうまくいきます。

## 前提MOD
- Minecraft Transit Railway（バージョン3）
- MTR-NTEまたはMTR-ANTE

MTR4系での動作は想定していません。