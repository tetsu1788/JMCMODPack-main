[JP]
パックをDL頂き有難うございます。
これは、日本風のレールやストラクチャ(トンネル、高架橋など)を追加するMTRmod向けのパックです。

-内容物-
・"botamochi129_Rail_Structure_Pack.zip"…MTR向けパックです。起動構成フォルダの"resourcepacks"の中にzipを入れてください。
リソースパック設定画面でbotamochi129_Rail_Structure_Pack.zipを有効化したら、ゲーム内でレールが追加されます。

-利用規約-
1.未改造の状態での再配布は、作者(ぼたもち)の許可を得てから行ってください。
2.パックの改造を行う場合、許可は不要ですがこのパックが原作であることを明記してください。
3.パックの改造品には、このパックが原作であることを明記してください。
4.パックを他媒体へ移植する場合、許可は不要ですがこのパックが原作であることを明記してください。
5.もし規約の違反行為が発見された場合、一時公開停止などの処置をとります。ご了承ください。
その他、「勝炭鉄道 MTR/RTMパック利用規約A(キットなど)」を適応します。

規約は以上になります。規約を守れば自由に使用して大丈夫です！

[EN]
Thank you for downloading the pack.
This is a pack for the MTRmod that adds Japanese-style rails and structures (tunnels, viaducts, etc.).

-Contents-
• “botamochi129_Rail_Structure_Pack.zip”…This is the MTR-compatible pack. Place the ZIP file in the “resourcepacks” folder within the game's configuration directory.  
After enabling the botamochi129_Rail_Structure_Pack.zip in the resource pack settings menu, the vehicles will be added in-game.

-Terms of Use-
1. Redistribution of the unmodified pack requires permission from the author (botomochi129).
2. Modifying the pack does not require permission, but you must clearly state that this pack is the original work.
3. Modified versions of the pack must clearly state that this pack is the original work.
4. Porting the pack to other media does not require permission, but you must clearly state that this pack is the original work.
5. Should any violation of these terms be discovered, measures such as temporary suspension of publication may be taken. Please be aware of this.
Additionally, the “Katan Railway MTR/RTM Pack Terms of Use A (Kits, etc.)” apply.  

The terms of use are as above. As long as you comply with the terms of use, you may use the pack freely!
(Translated with DeepL.)