importPackage(java.awt);
importPackage(java.awt.geom);
importPackage(java.io);
importPackage(java.net);
importPackage(java.util);
importPackage(java.lang);
importPackage(java.util.concurrent);

// UI設定：スロープ先端を上げる高さ（メートル単位、最大1.0m）
const slope_height_cfg = new ConfigResponder.TextField("slope_height", ComponentUtil.translatable("上げる高さ (m, 最大1.0)"), "0.2");

// スロープの仕様
const SLOPE_LENGTH = 1.0;   // 全長(奥行きZ方向) 1m (16ピクセル)
const SLOPE_WIDTH  = 2.0;   // 幅(横X方向) 2m (32ピクセル)
const SUBDIVISIONS = 8;     // 当たり判定の分割数
const MAX_HEIGHT_CAP = 1.0; // 上限値 (1.0m)
const MIN_HEIGHT = 0.005;   // Z-fighting防止用の初期オフセット(0.005m = 0.5cm)

function create(ctx, state, entity) {
    state.rate = new RateLimit(0.1);
    state.lastShapeStr = "";

    // 1. RawModel の読み込み
    state.slopeRawModel = ModelManager.loadRawModel(
        Resources.manager(),
        Resources.id("mtrsteamloco:eyecandies/other/platform_slope.obj"),
        null
    );
    
    // 2. DynamicModelHolder の生成と非同期アップロード
    state.dmhSlope = new DynamicModelHolder();
    if (state.slopeRawModel != null) {
        state.dmhSlope.uploadLater(state.slopeRawModel);
    }
}

function dispose(ctx, state, entity) {
    if (state.dmhSlope != null) {
        state.dmhSlope.close();
    }
}

function render(ctx, state, entity) {
    entity.registerCustomConfig(slope_height_cfg);

    // --- 1. 入力値の取得と上限制限 (最大 1.0m) ---
    let rawHeight = parseFloat(entity.getCustomConfig("slope_height") || "0.2");
    if (isNaN(rawHeight)) rawHeight = 0.2;
    let maxHeight = Math.min(MAX_HEIGHT_CAP, Math.max(0.0, rawHeight));

    // --- 2. doorValue の正規化 (0.0～0.5 で完了、0.5～1.0 は固定) ---
    let doorProgress = Math.min(1.0, entity.doorValue / 0.5);

    // --- 3. 現在の高さを計算 (初期オフセット + 進行度に応じた高さ) ---
    let currentHeight = MIN_HEIGHT + (maxHeight - MIN_HEIGHT) * doorProgress;

    // --- 4. モデルの描画（回転） ---
    let sinValue = Math.min(1.0, currentHeight / SLOPE_LENGTH);
    let angleRad = Math.asin(sinValue);

    // アップロード完了済みモデルの取得
    let uploadedModel = state.dmhSlope.getUploadedModel();
    if (uploadedModel != null) {
        let mat = new Matrices();
        mat.pushPose();

        // Z = 0.5m を回転の中心（支点）にする処理
        mat.translate(0.0, 0.0, 0.5);
        mat.rotateX(angleRad);
        mat.translate(0.0, 0.0, -0.5);

        ctx.drawModel(uploadedModel, mat);
        mat.popPose();
    }

    // --- 5. 衝突形状 (CollisionShape) の動的更新 ---
    if (state.rate.shouldUpdate()) {
        let shapeStr = generateSlopeCollisionShape(currentHeight, SUBDIVISIONS);
        
        if (shapeStr !== state.lastShapeStr) {
            entity.setCollisionShape(shapeStr);
            state.lastShapeStr = shapeStr;
        }
    }
}

/**
 * 高さ・分割数から衝突形状のフォーマット文字列を生成する関数
 */
function generateSlopeCollisionShape(heightMeter, steps) {
    let totalZ = SLOPE_LENGTH * 16.0; // 1m = 16px
    let maxX   = SLOPE_WIDTH * 16.0;  // 2m = 32px (幅)
    let maxY   = heightMeter * 16.0;  // メートルをピクセルに変換
    
    let stepZ = totalZ / steps;
    let shapes = [];

    for (let i = 0; i < steps; i++) {
        let z1 = (i * stepZ).toFixed(2);
        let z2 = ((i + 1) * stepZ).toFixed(2);
        
        let currentY = ((i + 1) / steps * maxY).toFixed(2);
        let y2 = Math.max(0.1, parseFloat(currentY));

        shapes.push(`0, 0, ${z1}, ${maxX}, ${y2}, ${z2}`);
    }

    return shapes.join(" / ");
}

function use(ctx, state, entity, player) {
}