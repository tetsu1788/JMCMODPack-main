MTR srt JRTrains pack for MTR4 readme

YouTube: https://www.youtube.com/@soodari6791

This pack require Minecraft Transit Railway Mod (Fabric 1.19.2~)made by jonafanho (MTR4 beta 11 or above)
Mod Link(MTR): https://www.curseforge.com/minecraft/mc-mods/minecraft-transit-railway

[Model parts developers]
* Bogie model is made by Meitetsu600v
* Chair, gangways are made by PC28K
* Wiper model is made by _Samhan
* DMU Sound provided by Szandor13

Terms and Conditions
1. This resource pack can be retextured freely, please credit soodari and model part developers.
when you proceed with the second creation using this resource pack. And you need to make separate folder to repaint. 
However, do not use only some model parts of this resource pack to transplant them into other resource packs.
2. Using this resource pack and the components of the model pack is deemed to be your own responsibility for everything involved.
3. We are not responsible for any problems with this model pack.
4. Do not Redistribute this pack privately. Please Share the original Download link.
5. This resource pack can be added in private or public MTR mod server.
6. Changing JVM Arguments from Xmx2G to Xmx4G~6G or more is recommended.

Trains
211 Series (Shonan livery)
415 Series (Kyushu livery)
203 Series (Joban livery)
e231 Series (Yamanote, Chuo-Sobu livery)
Kiha 54 (JR Hokkaido)