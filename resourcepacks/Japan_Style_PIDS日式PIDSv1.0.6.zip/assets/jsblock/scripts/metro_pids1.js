include(Resources.id("jsblock:scripts/pids_util.js"));

function create(ctx, state, pids) {}

function drawTrainInfo(ctx, pids, i, isArriving, customStationInfoList,customColor) {
    let pos_y = 0;
    let scale = 1.8;
    let route_number_scale = 1.4;
    let train_type_size_x = 33;
    let train_type_size_y = 15;
    let route_number_y_offset = 1.5;
    let station_number_font_scale = 0.7;
    let station_number_circle_size_bottom_x = 25;
    let station_number_circle_size_bottom_y = 25;
    let station_number_circle_size_middle_x = 22;
    let station_number_circle_size_middle_y = 22;
    let station_number_circle_size_top_x = 19;
    let station_number_circle_size_top_y = 19;
    let station_number_x_offset = 0;
    let station_number_y_offset = 0;
    let station_number_circle_y_offset = 0;
    let pos_station_name = 0;

    if (i == 0) {
        pos_y = 7;
        pos_station_name = 6;
    } else {
        pos_y = (i * 38) + (isArriving ? 8 : 0);
        pos_station_name = (i * 37) + (isArriving ? 9 : 0);
        if (isArriving) {
            scale = 1.25;
            route_number_y_offset = 1;
            station_number_font_scale = 0.5;
            station_number_circle_size_bottom_x = 20;
            station_number_circle_size_bottom_y = 20;
            station_number_circle_size_middle_x = 17;
            station_number_circle_size_middle_y = 17;
            station_number_circle_size_top_x = 14;
            station_number_circle_size_top_y = 14;
            train_type_size_x = 33;
            train_type_size_y = 12;
            route_number_scale = 1.25;
            station_number_x_offset = 2.5;
            station_number_y_offset = 1.5;
            station_number_circle_y_offset = 1;
        }
    }

    let arrival = pids.arrivals().get(i);
    if (arrival == null) return;

    if (arrival == undefined) {
        return;
    }


    let departure_time = new Date(arrival.departureTime());
    let hour = String(departure_time.getHours()).padStart(2, '0');
    let minute = String(departure_time.getMinutes()).padStart(2, '0');
    let timeStr = `${hour}:${minute}`;



    let isFound = false;
    let stationInfo = null;
    for (let j = 0; j < customStationInfoList.length; j++) {
        if (String(customStationInfoList[j].destination) === String(arrival.destination()).split("|")[0]) {
            isFound = true;
            stationInfo = customStationInfoList[j];
            break;
        }
    }


    if (isFound) {

        let stationType = String(stationInfo.stationType);
        if (stationType !== "border"){
            Texture.create("Station Icon")
                .texture("jsblock:resource/"+stationType+".png")
                .color(0xFFFFFF)
                .pos(70, pos_y - 6 + station_number_circle_y_offset)
                .size(station_number_circle_size_bottom_x, station_number_circle_size_bottom_y)
                .draw(ctx);
        }


        Texture.create("Station Icon")
            .texture("jsblock:resource/"+stationType+".png")
            .color(stationInfo.stationNumberColor)
            .pos(71.5, pos_y - 4.5 + station_number_circle_y_offset)
            .size(station_number_circle_size_middle_x, station_number_circle_size_middle_y)
            .draw(ctx);

        Texture.create("Station Icon")
            .texture("jsblock:resource/"+stationType+".png")
            .color(0xFFFFFF)
            .pos(73, pos_y - 3 + station_number_circle_y_offset)
            .size(station_number_circle_size_top_x, station_number_circle_size_top_y)
            .draw(ctx);

        Text.create("Route English Number")
            .size(8, 9)
            .stretchXY()
            .bold()
            .centerAlign()
            .text(stationInfo.stationNumber.split(" ")[0])
            .color(0x000000)
            .pos(37 + 17 + 28.5 - station_number_x_offset, pos_y + 1)
            .scale(station_number_font_scale)
            .draw(ctx);

        Text.create("Station Enlish Number")
            .size(8, 9)
            .stretchXY()
            .bold()
            .centerAlign()
            .text(stationInfo.stationNumber.split(" ")[1])
            .color(0x000000)
            .pos(37 + 17 + 28.5 - station_number_x_offset, pos_y + 6.5 - station_number_y_offset)
            .scale(station_number_font_scale)
            .draw(ctx);


    }




    let thisRouteColor = arrival.routeColor();
    for (let j=0;j<customColor.length; j++){
        if (String(customColor[j].trainType) === String(arrival.routeNumber()).split("|")[0]) {
            thisRouteColor = customColor[j].typeColor;
            break;
        }
    }



    Text.create("Arrival destination")
        .size(36, 9)
        .stretchXY()
        .centerAlign()
        .text(TextUtil.cycleString(arrival.destination()))
        .color(0xFFFFFF)
        .pos(140, pos_station_name)
        .scale(scale)
        .draw(ctx);



    Texture.create("Train Type Icon")
        .texture("jsblock:resource/rectangle.png")
        .color(thisRouteColor)
        .pos(37, pos_y - 1)
        .size(train_type_size_x, train_type_size_y)
        .draw(ctx);

    Text.create("Train Type")
        .size(18.5, 9)
        .stretchXY()
        .bold()
        .centerAlign()
        .text(TextUtil.cycleString(arrival.routeNumber()))
        .color(0xFFFFFF)
        .pos(37 + 17, pos_y - 0.55 + route_number_y_offset)
        .scale(route_number_scale - 0.1)
        .draw(ctx);

    Text.create("Arrival Time")
        .size(16, 9)
        .stretchXY()
        .leftAlign()
        .bold()
        .text(timeStr)
        .color(0xFFFFFF)
        .pos(4.3, pos_y)
        .scale(scale)
        .draw(ctx);
}

function render(ctx, state, pids) {

    let customMsg = pids.getCustomMessage(0);

    let customStationInfoList = []

    let customColor = []

    let customColorMsg = pids.getCustomMessage(1)


    if (customMsg != "") {
        let customDestinationList = customMsg.toString().split("///");
        for (let j = 0; j < customDestinationList.length; j++) {
            let customDestination = customDestinationList[j].trim();
            let stationInfo = customDestination.toString().split("//")
            customStationInfoList.push({
                "destination": String(stationInfo[0]).trim(),
                "stationNumber": String(stationInfo[1]).trim(),
                "stationNumberColor": stationInfo.length > 2 ? String(stationInfo[2]).trim() : "0x00FF00",
                "stationType": stationInfo.length > 3 ? "border" : "circle"
            })
        }
    }

    if (customColorMsg != "") {
        let customColorList = customColorMsg.toString().split("///");
        for (let j = 0; j < customColorList.length; j++) {
            let customDestination = customColorList[j].trim();
            let stationInfo = customDestination.toString().split("//")
            customColor.push({
                "trainType": String(stationInfo[0]).trim(),
                "typeColor": String(stationInfo[1]).trim()
            })
        }
    }



    let arrival_first = pids.arrivals().get(0);
    if (arrival_first == null || (((arrival_first.arrivalTime() - Date.now()) / 60000) > 60)) {
        Texture.create("Background")
            .texture("jsblock:resource/pid1.png")
            .size(pids.width, pids.height)
            .draw(ctx);
        Text.create("Arrival destination")
            .size(100, 12)
            .centerAlign()
            .text("☆☆☆　本日は終了しました　☆☆☆")
            .color(0xb9f47f)
            .pos((pids.width / 2), 6)
            .bold()
            .scale(1.8)
            .stretchXY()
            .draw(ctx);
        return
    }
    let eta = (arrival_first.arrivalTime() - Date.now()) / 60000;

    if (eta <= 0.5 && eta > 0) {
        Texture.create("Background")
            .texture("jsblock:resource/pid1_arrive.png")
            .size(pids.width, pids.height)
            .draw(ctx);

        let millis = Date.now();
        let isVisible = Math.floor(millis / 500) % 2 === 0;

        if (isVisible) {
            Text.create("Arrival Alert")
                .size(144, 9)
                .bold()
                .text(TextUtil.cycleString("電車がまいります|電車がまいります|Train Approaching|Train Approaching"))
                .color(0xFF0000)
                .pos(3, 25)
                .scale(1.5)
                .draw(ctx);
        }

        for (let i = 0; i < 2; i++) {
            drawTrainInfo(ctx, pids, i, true, customStationInfoList,customColor);
        }
    } else {
        Texture.create("Background")
            .texture("jsblock:resource/pid1.png")
            .size(pids.width, pids.height)
            .draw(ctx);

        for (let i = 0; i < 2; i++) {
            drawTrainInfo(ctx, pids, i, false,customStationInfoList,customColor);
        }
    }
}

function dispose(ctx, state, pids) {}